The typefaces are provided without any copyright restrictions.

http://typefaces.temporarystate.net